import type { ReactNode } from "react";
import {
  Activity,
  Angry,
  CircleAlert,
  CircleHelp,
  Eye,
  Hand,
  Laugh,
  LoaderCircle,
  Music2,
  MessageCircle,
  MoveRight,
  Play,
  RotateCcw,
  Smile,
  Sparkles,
  Waves,
} from "lucide-react";
import type { CharacterAction } from "@/lib/character-motion";
import "./character-preview-panel.css";

export type PreviewCharacterAction = CharacterAction;

export interface PreviewCharacterMetadata {
  id: string;
  name: string;
  category?: string;
  tone?: string;
  description?: string;
}

export interface CharacterPreviewPanelProps {
  /** The renderer-owned scene content, usually a canvas or WebGL view. */
  scene: ReactNode;
  character: PreviewCharacterMetadata;
  characters?: PreviewCharacterMetadata[];
  activeAction: PreviewCharacterAction;
  onAction: (action: PreviewCharacterAction) => void;
  /** Replaces the scene area while the renderer is preparing the character. */
  isLoading?: boolean;
  loadingContent?: ReactNode;
  /** Replaces the scene area when the renderer reports a recoverable failure. */
  error?: ReactNode;
  /** Shown when there is no scene node and no loading or error state. */
  fallbackContent?: ReactNode;
  className?: string;
}

const actionItems: {
  id: PreviewCharacterAction;
  label: string;
  Icon: typeof Activity;
}[] = [
  { id: "idle", label: "Idle", Icon: Activity },
  { id: "talk", label: "Talk", Icon: MessageCircle },
  { id: "walk", label: "Walk", Icon: MoveRight },
  { id: "jump", label: "Jump", Icon: Waves },
  { id: "laugh", label: "Laugh", Icon: Laugh },
  { id: "cry", label: "Cry", Icon: CircleAlert },
  { id: "angry", label: "Angry", Icon: Angry },
  { id: "surprised", label: "Surprised", Icon: CircleHelp },
  { id: "blink", label: "Blink", Icon: Eye },
  { id: "wave", label: "Wave", Icon: Hand },
  { id: "dance", label: "Dance", Icon: Music2 },
];

function SceneState({
  kind,
  children,
}: {
  kind: "loading" | "error" | "fallback";
  children: ReactNode;
}) {
  const stateLabel = kind === "loading" ? "Loading character preview" : kind === "error" ? "Preview unavailable" : "Character preview";
  const StateIcon = kind === "loading" ? LoaderCircle : kind === "error" ? CircleAlert : Sparkles;

  return (
    <div
      className={`character-preview__scene-state character-preview__scene-state--${kind}`}
      role={kind === "error" ? "alert" : "status"}
      aria-label={stateLabel}
      data-testid={`character-preview-${kind}`}
    >
      <span className="character-preview__state-icon" aria-hidden="true">
        <StateIcon size={20} strokeWidth={1.8} />
      </span>
      <div>{children}</div>
    </div>
  );
}

export function CharacterPreviewPanel({
  scene,
  character,
  characters,
  activeAction,
  onAction,
  isLoading = false,
  loadingContent,
  error,
  fallbackContent,
  className = "",
}: CharacterPreviewPanelProps) {
  const sceneContent = error ? (
    <SceneState kind="error">{error}</SceneState>
  ) : isLoading ? (
    <SceneState kind="loading">
      {loadingContent ?? (
        <>
          <strong>Building the scene</strong>
          <span className="character-preview__state-detail">Your character will be ready in a moment.</span>
        </>
      )}
    </SceneState>
  ) : scene ? (
    scene
  ) : (
    <SceneState kind="fallback">
      {fallbackContent ?? (
        <>
          <strong>Scene preview</strong>
          <span className="character-preview__state-detail">Choose a character to bring this space to life.</span>
        </>
      )}
    </SceneState>
  );

  return (
    <section
      className={`character-preview ${className}`.trim()}
      aria-label={`Character preview for ${character.name}`}
      data-testid="character-preview-panel"
    >
      <header className="character-preview__header">
        <div className="character-preview__identity">
          <span className="character-preview__eyebrow">
            <span className="character-preview__live-dot" aria-hidden="true" />
            CHARACTER VIEWPORT
          </span>
          <h2 className="character-preview__name" data-testid="character-preview-name">{character.name}</h2>
          <p className="character-preview__meta">
            {character.category && <span>{character.category}</span>}
            {character.category && character.tone && <span aria-hidden="true">·</span>}
            {character.tone && <span>{character.tone}</span>}
            {!character.category && !character.tone && <span>Scene character</span>}
          </p>
        </div>
        <span className="character-preview__ready">
          <span aria-hidden="true" />
          Preview
        </span>
      </header>

      {character.description && (
        <p className="character-preview__description">{character.description}</p>
      )}
      {characters && characters.length > 1 && (
        <div className="character-preview__cast" aria-label="Characters in this preview">
          <span>CAST</span>
          <div>
            {characters.map((member) => (
              <span key={member.id} data-testid={`character-preview-cast-${member.id}`}>{member.name}</span>
            ))}
          </div>
        </div>
      )}

      <div
        className="character-preview__viewport"
        data-testid="character-preview-viewport"
        aria-label={`3D scene viewport for ${character.name}`}
      >
        <div className="character-preview__viewport-grid" aria-hidden="true" />
        <div className="character-preview__viewport-scene">{sceneContent}</div>
        <span className="character-preview__viewport-caption">
          <span className="character-preview__caption-mark" aria-hidden="true" />
          LIVE PREVIEW
        </span>
        <span className="character-preview__viewport-corner" aria-hidden="true">
          <RotateCcw size={13} />
          DRAG TO ORBIT
        </span>
      </div>

      <div className="character-preview__controls">
        <div className="character-preview__controls-heading">
          <div>
            <span className="character-preview__section-label">QUICK ACTIONS</span>
            <span className="character-preview__hint">Set the scene’s energy</span>
          </div>
          <span className="character-preview__action-status" aria-live="polite" data-testid="character-preview-active-action">
            <Play size={12} fill="currentColor" aria-hidden="true" />
            {actionItems.find((action) => action.id === activeAction)?.label ?? "Idle"}
          </span>
        </div>
        <div className="character-preview__action-grid" role="group" aria-label="Character actions">
          {actionItems.map(({ id, label, Icon }) => {
            const selected = id === activeAction;
            return (
              <button
                key={id}
                type="button"
                className={`character-preview__action${selected ? " is-active" : ""}`}
                aria-label={`${label} ${selected ? "(active)" : ""}`.trim()}
                aria-pressed={selected}
                data-testid={`character-preview-action-${id}`}
                onClick={() => onAction(id)}
              >
                <Icon size={16} strokeWidth={1.9} aria-hidden="true" />
                <span>{label}</span>
              </button>
            );
          })}
        </div>
        <p className="character-preview__footnote">
          <Smile size={13} strokeWidth={1.8} aria-hidden="true" />
          Expressions and motion are preview-only
        </p>
      </div>
    </section>
  );
}

export default CharacterPreviewPanel;
