import { Canvas } from "@react-three/fiber";
import { OrbitControls } from "@react-three/drei";
import type { CharacterDefinition } from "@/lib/character-catalog";
import type { CharacterAction, LipSyncFrame } from "@/lib/character-motion";
import { ProceduralCharacter } from "./ProceduralCharacter";

export interface CharacterCanvasProps {
  characters: CharacterDefinition[];
  action: CharacterAction;
  reducedMotion: boolean;
  lowCost: boolean;
  lipSyncByCharacter: Record<string, LipSyncFrame>;
  onReady: () => void;
}

export function CharacterCanvas({
  characters,
  action,
  reducedMotion,
  lowCost,
  lipSyncByCharacter,
  onReady,
}: CharacterCanvasProps) {
  const spacing = characters.length < 2 ? 0 : Math.min(1.22, 2.55 / (characters.length - 1));

  return (
    <Canvas
      camera={{ position: [0, 2.4, 7.2], fov: 31, near: 0.1, far: 30 }}
      dpr={lowCost ? 1 : [1, 1.5]}
      frameloop={reducedMotion ? "demand" : "always"}
      gl={{
        alpha: true,
        antialias: !lowCost,
        powerPreference: "low-power",
        preserveDrawingBuffer: false,
      }}
      onCreated={(state) => {
        state.gl.setClearColor("#151f1b", 0);
        onReady();
      }}
      aria-label={`3D preview of ${characters.map((character) => character.name).join(", ")}`}
    >
      <ambientLight intensity={1.45} />
      <directionalLight position={[-3.5, 5.5, 5]} intensity={2.4} />
      <pointLight position={[3, 2.5, -3]} intensity={0.55} color="#b7f36b" />
      <mesh position={[0, -0.075, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <circleGeometry args={[2.7, lowCost ? 20 : 32]} />
        <meshStandardMaterial color="#263329" roughness={0.96} flatShading />
      </mesh>
      {characters.map((character, index) => (
        <group
          key={character.id}
          position={[(index - (characters.length - 1) / 2) * spacing, 0, 0]}
        >
          <ProceduralCharacter
            character={character}
            action={action}
            reducedMotion={reducedMotion}
            seed={index + character.id.length}
            lipSync={lipSyncByCharacter[character.id]}
          />
        </group>
      ))}
      <OrbitControls
        makeDefault
        target={[0, 1.18, 0]}
        enablePan={false}
        enableDamping={!lowCost}
        dampingFactor={0.08}
        minDistance={5.8}
        maxDistance={8.2}
        minPolarAngle={0.82}
        maxPolarAngle={1.68}
        rotateSpeed={0.72}
      />
    </Canvas>
  );
}

export default CharacterCanvas;
