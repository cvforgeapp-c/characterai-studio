import { useMemo } from "react";
import { CatmullRomCurve3, Vector3 } from "three";
import type { CharacterDefinition } from "@/lib/character-catalog";

function Oval({
  color,
  position,
  scale,
  rotation,
}: {
  color: string;
  position: [number, number, number];
  scale: [number, number, number];
  rotation?: [number, number, number];
}) {
  return (
    <mesh position={position} scale={scale} rotation={rotation}>
      <sphereGeometry args={[1, 10, 8]} />
      <meshStandardMaterial color={color} flatShading roughness={0.86} />
    </mesh>
  );
}

function Cone({
  color,
  position,
  scale = [1, 1, 1],
  rotation,
}: {
  color: string;
  position: [number, number, number];
  scale?: [number, number, number];
  rotation?: [number, number, number];
}) {
  return (
    <mesh position={position} scale={scale} rotation={rotation}>
      <coneGeometry args={[0.5, 1, 7]} />
      <meshStandardMaterial color={color} flatShading roughness={0.82} />
    </mesh>
  );
}

function BananaBody({ color, accent }: { color: string; accent: string }) {
  const curve = useMemo(
    () => new CatmullRomCurve3([
      new Vector3(-0.24, -0.48, 0),
      new Vector3(-0.12, -0.1, 0),
      new Vector3(0.16, 0.26, 0),
      new Vector3(0.3, 0.65, 0),
    ]),
    [],
  );

  return (
    <group position={[0, 0.92, 0]}>
      <mesh rotation={[0, 0, -0.08]}>
        <tubeGeometry args={[curve, 10, 0.28, 7, false]} />
        <meshStandardMaterial color={color} flatShading roughness={0.8} />
      </mesh>
      <Oval color={accent} position={[-0.23, -0.5, 0]} scale={[0.1, 0.1, 0.11]} />
      <Oval color={accent} position={[0.3, 0.66, 0]} scale={[0.1, 0.1, 0.11]} />
    </group>
  );
}

function CharacterBody({ character }: { character: CharacterDefinition }) {
  const { colors, proportions, archetype } = character;
  const [width, height, depth] = proportions.body;

  if (archetype === "broccoli") {
    return (
      <group>
        <mesh position={[0, 0.49, 0]}>
          <cylinderGeometry args={[0.15, 0.2, 0.68, 7]} />
          <meshStandardMaterial color={colors.muzzle} flatShading roughness={0.9} />
        </mesh>
        <Oval color={colors.body} position={[0, 0.91, 0]} scale={[0.34, 0.35, 0.33]} />
        <Oval color={colors.head} position={[-0.22, 0.84, 0.02]} scale={[0.27, 0.3, 0.28]} />
        <Oval color={colors.body} position={[0.22, 0.84, 0.02]} scale={[0.28, 0.29, 0.28]} />
        <Oval color={colors.head} position={[0, 1.12, 0]} scale={[0.29, 0.3, 0.28]} />
      </group>
    );
  }

  if (archetype === "carrot") {
    return (
      <group position={[0, 0.86, 0]}>
        <mesh rotation={[0, 0, Math.PI]}>
          <coneGeometry args={[width, height * 1.55, 9]} />
          <meshStandardMaterial color={colors.body} flatShading roughness={0.88} />
        </mesh>
        {[-0.15, 0, 0.15].map((x, index) => (
          <Oval
            key={index}
            color={colors.accent}
            position={[x, height * 0.73, 0]}
            scale={[0.07, 0.3, 0.06]}
            rotation={[0, 0, (index - 1) * 0.38]}
          />
        ))}
      </group>
    );
  }

  if (archetype === "banana") {
    return <BananaBody color={colors.body} accent={colors.accent} />;
  }

  if (archetype === "onion") {
    return (
      <group>
        <Oval color={colors.body} position={[0, 0.82, 0]} scale={[width, height * 0.86, depth]} />
        <Oval color={colors.head} position={[0, 0.85, 0.03]} scale={[width * 0.78, height * 0.72, depth * 0.94]} />
        <Cone color={colors.accent} position={[0, 1.44, 0]} scale={[0.15, 0.33, 0.12]} />
      </group>
    );
  }

  if (archetype === "potato") {
    return (
      <group>
        <Oval color={colors.body} position={[0, 0.83, 0]} scale={[width, height, depth]} rotation={[0, 0, -0.16]} />
        {[
          [-0.24, 0.94, 0.31],
          [0.21, 0.7, 0.32],
          [0.04, 1.13, 0.26],
        ].map((position, index) => (
          <Oval
            key={index}
            color={colors.accent}
            position={position as [number, number, number]}
            scale={[0.045, 0.035, 0.018]}
          />
        ))}
      </group>
    );
  }

  if (archetype === "tomato" || archetype === "orange") {
    return (
      <group>
        <Oval color={colors.body} position={[0, 0.82, 0]} scale={[width, height, depth]} />
        <Oval color={colors.accent} position={[0, 1.39, 0]} scale={[0.08, 0.11, 0.07]} />
        {[-1, 0, 1].map((side) => (
          <Oval
            key={side}
            color={colors.accent}
            position={[side * 0.13, 1.39, 0]}
            scale={[0.16, 0.045, 0.07]}
            rotation={[0, 0, side * -0.45]}
          />
        ))}
      </group>
    );
  }

  return (
    <Oval
      color={colors.body}
      position={[0, 0.83, 0]}
      scale={[width, height, depth]}
      rotation={archetype === "dog" || archetype === "bear" ? [0, 0, -0.04] : undefined}
    />
  );
}

function HeadDecoration({ character }: { character: CharacterDefinition }) {
  const { colors, proportions, archetype } = character;
  const [width, height, depth] = proportions.head;

  switch (archetype) {
    case "lion":
      return (
        <>
          <Oval color={colors.accent} position={[0, -0.01, -0.055]} scale={[width * 1.28, height * 1.27, depth * 0.98]} />
          {Array.from({ length: 8 }, (_, index) => {
            const angle = (index / 8) * Math.PI * 2;
            return (
              <Cone
                key={index}
                color={colors.accent}
                position={[Math.sin(angle) * width * 0.92, Math.cos(angle) * height * 0.86, -0.06]}
                scale={[0.29, 0.38, 0.25]}
                rotation={[0, 0, -angle]}
              />
            );
          })}
        </>
      );
    case "goat":
      return (
        <>
          <Cone color={colors.accent} position={[-width * 0.51, height * 0.86, -0.02]} scale={[0.18, 0.58, 0.17]} rotation={[0, 0, 0.22]} />
          <Cone color={colors.accent} position={[width * 0.51, height * 0.86, -0.02]} scale={[0.18, 0.58, 0.17]} rotation={[0, 0, -0.22]} />
          <Oval color={colors.muzzle} position={[0, -height * 0.23, depth * 0.94]} scale={[width * 0.42, height * 0.25, 0.11]} />
        </>
      );
    case "chicken":
      return (
        <>
          <Oval color={colors.accent} position={[-0.1, height * 0.95, 0]} scale={[0.1, 0.18, 0.08]} />
          <Oval color={colors.accent} position={[0.04, height * 1.02, 0]} scale={[0.1, 0.23, 0.08]} />
          <Oval color={colors.accent} position={[0.17, height * 0.94, 0]} scale={[0.1, 0.16, 0.08]} />
          <Cone color={colors.muzzle} position={[0, -0.02, depth * 1.12]} scale={[0.22, 0.29, 0.2]} rotation={[Math.PI / 2, 0, 0]} />
          <Oval color={colors.accent} position={[-0.08, -height * 0.38, depth * 0.96]} scale={[0.1, 0.15, 0.07]} />
          <Oval color={colors.accent} position={[0.08, -height * 0.38, depth * 0.96]} scale={[0.1, 0.15, 0.07]} />
        </>
      );
    case "dog":
      return (
        <>
          <Oval color={colors.accent} position={[-width * 0.91, -0.07, -0.01]} scale={[0.3, 0.43, 0.2]} rotation={[0, 0, -0.25]} />
          <Oval color={colors.accent} position={[width * 0.91, -0.07, -0.01]} scale={[0.3, 0.43, 0.2]} rotation={[0, 0, 0.25]} />
          <Oval color={colors.muzzle} position={[0, -height * 0.27, depth * 0.96]} scale={[width * 0.49, height * 0.29, 0.12]} />
        </>
      );
    case "cat":
      return (
        <>
          <Cone color={colors.body} position={[-width * 0.63, height * 0.9, -0.01]} scale={[0.34, 0.65, 0.22]} rotation={[0, 0, 0.16]} />
          <Cone color={colors.body} position={[width * 0.63, height * 0.9, -0.01]} scale={[0.34, 0.65, 0.22]} rotation={[0, 0, -0.16]} />
          <Oval color={colors.muzzle} position={[0, -height * 0.28, depth * 0.93]} scale={[width * 0.45, height * 0.25, 0.1]} />
        </>
      );
    case "monkey":
      return (
        <>
          <Oval color={colors.accent} position={[-width * 0.91, 0, 0]} scale={[0.2, 0.23, 0.12]} />
          <Oval color={colors.accent} position={[width * 0.91, 0, 0]} scale={[0.2, 0.23, 0.12]} />
          <Oval color={colors.muzzle} position={[0, -height * 0.2, depth * 0.93]} scale={[width * 0.63, height * 0.39, 0.13]} />
        </>
      );
    case "elephant":
      return (
        <>
          <Oval color={colors.accent} position={[-width * 0.93, -0.02, -0.03]} scale={[0.38, 0.5, 0.18]} rotation={[0, 0, -0.2]} />
          <Oval color={colors.accent} position={[width * 0.93, -0.02, -0.03]} scale={[0.38, 0.5, 0.18]} rotation={[0, 0, 0.2]} />
          <Oval color={colors.body} position={[0, -height * 0.34, depth * 0.99]} scale={[0.16, 0.4, 0.16]} rotation={[0.18, 0, -0.06]} />
          <Oval color={colors.muzzle} position={[0, -height * 0.58, depth * 1.01]} scale={[0.14, 0.15, 0.14]} />
          <Cone color="#f8f0dd" position={[-0.16, -height * 0.3, depth * 0.93]} scale={[0.055, 0.24, 0.055]} rotation={[0, 0, 0.12]} />
          <Cone color="#f8f0dd" position={[0.16, -height * 0.3, depth * 0.93]} scale={[0.055, 0.24, 0.055]} rotation={[0, 0, -0.12]} />
        </>
      );
    case "rabbit":
      return (
        <>
          <Oval color={colors.body} position={[-width * 0.4, height * 1.2, -0.04]} scale={[0.16, 0.55, 0.13]} rotation={[0, 0, 0.08]} />
          <Oval color={colors.accent} position={[-width * 0.4, height * 1.2, depth * 0.5]} scale={[0.07, 0.38, 0.035]} rotation={[0, 0, 0.08]} />
          <Oval color={colors.body} position={[width * 0.4, height * 1.2, -0.04]} scale={[0.16, 0.55, 0.13]} rotation={[0, 0, -0.08]} />
          <Oval color={colors.accent} position={[width * 0.4, height * 1.2, depth * 0.5]} scale={[0.07, 0.38, 0.035]} rotation={[0, 0, -0.08]} />
          <Oval color={colors.muzzle} position={[0, -height * 0.26, depth * 0.92]} scale={[width * 0.48, height * 0.26, 0.1]} />
        </>
      );
    case "cow":
      return (
        <>
          <Cone color={colors.muzzle} position={[-width * 0.62, height * 0.83, -0.02]} scale={[0.18, 0.36, 0.14]} rotation={[0, 0, 0.15]} />
          <Cone color={colors.muzzle} position={[width * 0.62, height * 0.83, -0.02]} scale={[0.18, 0.36, 0.14]} rotation={[0, 0, -0.15]} />
          <Oval color={colors.accent} position={[-width * 0.78, 0.05, 0.03]} scale={[0.15, 0.22, 0.1]} />
          <Oval color={colors.accent} position={[width * 0.77, -0.23, 0.02]} scale={[0.14, 0.18, 0.1]} />
          <Oval color={colors.muzzle} position={[0, -height * 0.3, depth * 0.93]} scale={[width * 0.55, height * 0.32, 0.12]} />
        </>
      );
    case "bear":
      return (
        <>
          <Oval color={colors.accent} position={[-width * 0.72, height * 0.69, -0.04]} scale={[0.18, 0.18, 0.12]} />
          <Oval color={colors.accent} position={[width * 0.72, height * 0.69, -0.04]} scale={[0.18, 0.18, 0.12]} />
          <Oval color={colors.muzzle} position={[0, -height * 0.23, depth * 0.93]} scale={[width * 0.54, height * 0.32, 0.12]} />
        </>
      );
    case "tomato":
    case "onion":
    case "potato":
    case "broccoli":
    case "carrot":
    case "banana":
    case "orange":
      return (
        <>
          {archetype === "carrot" && [-0.2, 0, 0.2].map((side) => (
            <Oval key={side} color={colors.accent} position={[side, height * 1.15, 0]} scale={[0.08, 0.32, 0.07]} rotation={[0, 0, side * 2]} />
          ))}
          {archetype === "banana" && <Oval color={colors.muzzle} position={[0, -0.16, depth * 0.92]} scale={[width * 0.43, height * 0.24, 0.1]} />}
          {archetype === "tomato" && <Oval color={colors.accent} position={[0, height * 0.91, 0]} scale={[0.16, 0.08, 0.08]} />}
          {archetype === "orange" && <Oval color={colors.accent} position={[0.08, height * 0.9, 0]} scale={[0.16, 0.06, 0.08]} rotation={[0, 0, -0.35]} />}
        </>
      );
  }
}

export function CharacterTorso({ character }: { character: CharacterDefinition }) {
  return <CharacterBody character={character} />;
}

export function CharacterHeadShape({ character }: { character: CharacterDefinition }) {
  const [width, height, depth] = character.proportions.head;
  return (
    <group>
      <HeadDecoration character={character} />
      <Oval
        color={character.colors.head}
        position={[0, 0, 0]}
        scale={[width, height, depth]}
      />
      {character.archetype !== "chicken" && character.archetype !== "elephant" && character.archetype !== "carrot" && (
        <HeadDetails character={character} />
      )}
    </group>
  );
}

export function HeadDetails({ character }: { character: CharacterDefinition }) {
  const [width, height, depth] = character.proportions.head;
  return (
    <group>
      {character.archetype !== "lion" && character.archetype !== "goat" && character.archetype !== "dog" &&
        character.archetype !== "cat" && character.archetype !== "monkey" && character.archetype !== "elephant" &&
        character.archetype !== "rabbit" && character.archetype !== "cow" && character.archetype !== "bear" && (
          <Oval color={character.colors.muzzle} position={[0, -height * 0.22, depth * 0.94]} scale={[width * 0.43, height * 0.25, 0.1]} />
        )}
      <Oval color={character.colors.detail} position={[0, -height * 0.31, depth * 1.08]} scale={[0.09, 0.065, 0.04]} />
    </group>
  );
}
