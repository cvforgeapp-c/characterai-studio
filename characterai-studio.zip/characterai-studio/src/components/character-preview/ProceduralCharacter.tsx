import { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import type { Mesh, Group } from "three";
import type { CharacterDefinition } from "@/lib/character-catalog";
import {
  createProceduralMotionDriver,
  type CharacterAction,
  type CharacterMotionDriver,
  type LipSyncFrame,
} from "@/lib/character-motion";
import { CharacterHeadShape, CharacterTorso } from "./CharacterAnatomy";

function Eye({
  character,
  index,
  eyeRef,
  pupilRef,
  browRef,
}: {
  character: CharacterDefinition;
  index: number;
  eyeRef: (node: Mesh | null) => void;
  pupilRef: (node: Mesh | null) => void;
  browRef: (node: Mesh | null) => void;
}) {
  const [headWidth, headHeight, headDepth] = character.proportions.head;
  const side = index === 0 ? -1 : 1;
  const eyeX = side * headWidth * 0.37;
  const eyeY = headHeight * 0.14;
  const eyeZ = headDepth * 0.91;
  const scale = Math.max(0.8, Math.min(headWidth / 0.42, 1.25));

  return (
    <group>
      <mesh ref={eyeRef} position={[eyeX, eyeY, eyeZ]} scale={[0.105 * scale, 0.12 * scale, 0.065]}>
        <sphereGeometry args={[1, 10, 8]} />
        <meshStandardMaterial color="#fffdf7" flatShading roughness={0.55} />
      </mesh>
      <mesh ref={pupilRef} position={[eyeX, eyeY - 0.008, eyeZ + 0.055]} scale={[0.048 * scale, 0.065 * scale, 0.035]}>
        <sphereGeometry args={[1, 8, 6]} />
        <meshStandardMaterial color={character.colors.detail} flatShading roughness={0.45} />
      </mesh>
      <mesh
        ref={browRef}
        position={[eyeX, eyeY + 0.15 * scale, eyeZ - 0.005]}
        rotation={[0, 0, side * -0.04]}
        scale={[0.16 * scale, 0.045 * scale, 0.035]}
      >
        <sphereGeometry args={[1, 8, 6]} />
        <meshStandardMaterial color={character.colors.detail} flatShading roughness={0.7} />
      </mesh>
    </group>
  );
}

function Leg({
  color,
  x,
  z,
  length,
  legRef,
}: {
  color: string;
  x: number;
  z: number;
  length: number;
  legRef: (node: Group | null) => void;
}) {
  return (
    <group ref={legRef} position={[x, length * 0.52, z]}>
      <mesh position={[0, -length * 0.18, 0]}>
        <cylinderGeometry args={[0.075, 0.09, length * 0.7, 7]} />
        <meshStandardMaterial color={color} flatShading roughness={0.9} />
      </mesh>
      <mesh position={[0.015, -length * 0.48, 0.07]} scale={[0.16, 0.085, 0.2]}>
        <sphereGeometry args={[1, 8, 6]} />
        <meshStandardMaterial color={color} flatShading roughness={0.9} />
      </mesh>
    </group>
  );
}

function Arm({
  character,
  side,
  armRef,
}: {
  character: CharacterDefinition;
  side: -1 | 1;
  armRef: (node: Group | null) => void;
}) {
  const [width] = character.proportions.body;
  return (
    <group ref={armRef} position={[side * width * 0.83, 1.04, 0.03]}>
      <mesh position={[side * 0.09, -0.22, 0.01]} rotation={[0, 0, side * -0.28]} scale={[0.105, 0.29, 0.12]}>
        <sphereGeometry args={[1, 8, 6]} />
        <meshStandardMaterial color={character.colors.body} flatShading roughness={0.88} />
      </mesh>
      <mesh position={[side * 0.15, -0.4, 0.04]} scale={[0.095, 0.105, 0.1]}>
        <sphereGeometry args={[1, 8, 6]} />
        <meshStandardMaterial color={character.colors.foot} flatShading roughness={0.9} />
      </mesh>
    </group>
  );
}

export interface ProceduralCharacterProps {
  character: CharacterDefinition;
  action: CharacterAction;
  reducedMotion?: boolean;
  lipSync?: LipSyncFrame;
  seed?: number;
}

export function ProceduralCharacter({
  character,
  action,
  reducedMotion = false,
  lipSync,
  seed = 0,
}: ProceduralCharacterProps) {
  const root = useRef<Group>(null);
  const torso = useRef<Group>(null);
  const head = useRef<Group>(null);
  const eyes = useRef<Array<Mesh | null>>([null, null]);
  const pupils = useRef<Array<Mesh | null>>([null, null]);
  const brows = useRef<Array<Mesh | null>>([null, null]);
  const mouth = useRef<Mesh>(null);
  const arms = useRef<Array<Group | null>>([null, null]);
  const legs = useRef<Array<Group | null>>([null, null, null, null]);
  const tearGroup = useRef<Group>(null);
  const motionDriver = useMemo<CharacterMotionDriver>(
    () => createProceduralMotionDriver(seed),
    [seed],
  );
  const [bodyWidth, , bodyDepth] = character.proportions.body;
  const [headWidth, headHeight, headDepth] = character.proportions.head;
  const legLength = character.proportions.legLength;

  useFrame((_, delta) => {
    const pose = motionDriver.update(delta, { action, reducedMotion, lipSync });
    if (root.current) {
      root.current.position.y = pose.verticalOffset;
      root.current.position.x = pose.horizontalOffset;
      root.current.rotation.z = pose.bodyTilt;
    }
    if (torso.current) {
      torso.current.rotation.z = pose.bodyTilt * 0.55;
    }
    if (head.current) {
      head.current.rotation.z = pose.headTilt;
      head.current.rotation.x = pose.headPitch;
    }

    for (const [index, eye] of eyes.current.entries()) {
      if (eye) {
        const squint = pose.eyeSquint * (action === "angry" ? 0.35 : 0.65);
        eye.scale.y = (0.12 * Math.max(0.8, Math.min(headWidth / 0.42, 1.25))) *
          Math.max(0.12, 1 - pose.blink * 0.96 - squint);
        eye.position.y = headHeight * 0.14 - pose.blink * 0.018;
      }
      const pupil = pupils.current[index];
      if (pupil) {
        pupil.scale.y = (0.065 * Math.max(0.8, Math.min(headWidth / 0.42, 1.25))) *
          Math.max(0.1, 1 - pose.blink * 0.96);
        pupil.position.y = headHeight * 0.14 - 0.008 - pose.blink * 0.018;
      }
      const brow = brows.current[index];
      if (brow) {
        const side = index === 0 ? 1 : -1;
        brow.rotation.z = side * pose.browTilt;
      }
    }

    if (mouth.current) {
      mouth.current.scale.y = 0.035 + pose.mouthOpen * 0.19;
      mouth.current.position.y = -headHeight * 0.43 - pose.mouthOpen * 0.018;
    }
    if (tearGroup.current) {
      tearGroup.current.visible = pose.tears > 0.5;
    }

    arms.current.forEach((arm, index) => {
      if (arm) {
        const side = index === 0 ? -1 : 1;
        arm.rotation.z = side * pose.armSwing;
      }
    });
    legs.current.forEach((leg, index) => {
      if (leg) {
        const phase = index % 2 === 0 ? 0 : Math.PI;
        leg.rotation.x = Math.sin(pose.legSwing + phase) * 0.58;
      }
    });
  });

  const bodyPositions: [number, number, number][] = [
    [-bodyWidth * 0.57, -bodyDepth * 0.38, 0],
    [bodyWidth * 0.57, -bodyDepth * 0.38, 0],
    [-bodyWidth * 0.57, bodyDepth * 0.38, 0],
    [bodyWidth * 0.57, bodyDepth * 0.38, 0],
  ];

  return (
    <group ref={root} scale={character.proportions.size * 0.84}>
      <group ref={torso}>
        <CharacterTorso character={character} />
        {bodyPositions.map(([x, z], index) => (
          <Leg
            key={index}
            color={character.colors.foot}
            x={x}
            z={z}
            length={legLength}
            legRef={(node) => {
              legs.current[index] = node;
            }}
          />
        ))}
        <Arm
          character={character}
          side={-1}
          armRef={(node) => {
            arms.current[0] = node;
          }}
        />
        <Arm
          character={character}
          side={1}
          armRef={(node) => {
            arms.current[1] = node;
          }}
        />
        <group ref={head} position={[0, 1.58, 0]}>
          <CharacterHeadShape character={character} />
          <Eye
            character={character}
            index={0}
            eyeRef={(node) => {
              eyes.current[0] = node;
            }}
            pupilRef={(node) => {
              pupils.current[0] = node;
            }}
            browRef={(node) => {
              brows.current[0] = node;
            }}
          />
          <Eye
            character={character}
            index={1}
            eyeRef={(node) => {
              eyes.current[1] = node;
            }}
            pupilRef={(node) => {
              pupils.current[1] = node;
            }}
            browRef={(node) => {
              brows.current[1] = node;
            }}
          />
          <mesh
            ref={mouth}
            position={[0, -headHeight * 0.43, headDepth * 1.08]}
            scale={[0.13, 0.045, 0.04]}
          >
            <sphereGeometry args={[1, 10, 7]} />
            <meshStandardMaterial color="#38251e" flatShading roughness={0.7} />
          </mesh>
          <group ref={tearGroup} visible={false}>
              <mesh position={[-headWidth * 0.39, -0.15, headDepth * 0.96]} scale={[0.035, 0.09, 0.03]}>
                <sphereGeometry args={[1, 8, 6]} />
                <meshStandardMaterial color="#70c8e7" flatShading roughness={0.35} />
              </mesh>
              <mesh position={[headWidth * 0.39, -0.15, headDepth * 0.96]} scale={[0.035, 0.09, 0.03]}>
                <sphereGeometry args={[1, 8, 6]} />
                <meshStandardMaterial color="#70c8e7" flatShading roughness={0.35} />
              </mesh>
          </group>
        </group>
      </group>
    </group>
  );
}
