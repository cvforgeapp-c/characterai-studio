import { Component, Suspense, lazy, useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import type { CharacterDefinition } from "@/lib/character-catalog";
import type { CharacterAction, LipSyncFrame } from "@/lib/character-motion";

const LazyCharacterCanvas = lazy(() => import("./CharacterCanvas"));

function prefersLowCostRendering() {
  if (typeof window === "undefined") return false;
  const coarsePointer = window.matchMedia("(pointer: coarse)").matches;
  const narrowScreen = window.matchMedia("(max-width: 700px)").matches;
  const deviceMemory = (navigator as Navigator & { deviceMemory?: number }).deviceMemory;
  const saveData = (navigator as Navigator & { connection?: { saveData?: boolean } }).connection?.saveData;
  return coarsePointer || narrowScreen || saveData === true || (deviceMemory !== undefined && deviceMemory < 4);
}

class PreviewErrorBoundary extends Component<
  { children: ReactNode; onError: () => void },
  { hasError: boolean }
> {
  state = { hasError: false };

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error: Error) {
    console.warn("Character preview could not be rendered.", error);
    this.props.onError();
  }

  render() {
    if (this.state.hasError) return null;
    return this.props.children;
  }
}

export interface CharacterStageProps {
  characters: CharacterDefinition[];
  action: CharacterAction;
  reducedMotion?: boolean;
  lipSyncByCharacter?: Record<string, LipSyncFrame>;
  onReady?: () => void;
  onError?: () => void;
}

export function CharacterStage({
  characters,
  action,
  reducedMotion = false,
  lipSyncByCharacter = {},
  onReady,
  onError,
}: CharacterStageProps) {
  const viewportRef = useRef<HTMLDivElement>(null);
  const [isNearViewport, setIsNearViewport] = useState(false);
  const [pageVisible, setPageVisible] = useState(
    () => typeof document === "undefined" || document.visibilityState === "visible",
  );
  const [lowCost, setLowCost] = useState(prefersLowCostRendering);
  const [canvasError, setCanvasError] = useState(false);
  const active = isNearViewport && pageVisible;
  const castKey = characters.map((character) => character.id).join("|");
  const [readyCast, setReadyCast] = useState("");
  const ready = readyCast === castKey;
  const fallbackLabel = useMemo(
    () => characters.map((character) => character.name).join(", "),
    [characters],
  );
  const handleReady = useCallback(() => {
    setReadyCast(castKey);
    onReady?.();
  }, [castKey, onReady]);
  const handleError = useCallback(() => {
    setCanvasError(true);
  }, []);

  useEffect(() => {
    const viewport = viewportRef.current?.closest(".character-preview__viewport");
    if (!viewport) {
      setIsNearViewport(true);
      return;
    }
    if (!("IntersectionObserver" in window)) {
      setIsNearViewport(true);
      return;
    }
    const observer = new IntersectionObserver(
      ([entry]) => setIsNearViewport(entry.isIntersecting),
      { rootMargin: "100px 0px" },
    );
    observer.observe(viewport);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const onVisibilityChange = () => setPageVisible(document.visibilityState === "visible");
    const onResize = () => setLowCost(prefersLowCostRendering());
    document.addEventListener("visibilitychange", onVisibilityChange);
    window.addEventListener("resize", onResize);
    return () => {
      document.removeEventListener("visibilitychange", onVisibilityChange);
      window.removeEventListener("resize", onResize);
    };
  }, []);

  useEffect(() => {
    if (!active) setReadyCast("");
  }, [active]);

  useEffect(() => {
    if (!active || ready || canvasError) return;
    const timeout = window.setTimeout(() => setCanvasError(true), 10000);
    return () => window.clearTimeout(timeout);
  }, [active, ready, canvasError]);

  useEffect(() => {
    if (canvasError) onError?.();
  }, [canvasError, onError]);

  if (characters.length === 0) {
    return (
      <div className="character-stage-empty" role="status" data-testid="character-stage-empty">
        Select a character above to preview your cast.
      </div>
    );
  }

  return (
    <div className="character-stage" ref={viewportRef} data-testid="character-stage">
      {!active && !canvasError && (
        <div className="character-stage-standby" role="status" data-testid="character-stage-standby">
          Preview starts when this section is in view.
        </div>
      )}
      {active && canvasError && (
        <div className="character-stage-fallback" role="status" data-testid="character-stage-fallback">
          <strong>3D preview is unavailable here.</strong>
          <span>{fallbackLabel} is still in your selected cast.</span>
        </div>
      )}
      {active && !canvasError && (
        <>
          <PreviewErrorBoundary key={castKey} onError={handleError}>
            <Suspense
              fallback={(
                <div className="character-stage-loading" role="status" data-testid="character-stage-loading">
                  Loading the 3D engine…
                </div>
              )}
            >
              <LazyCharacterCanvas
                characters={characters}
                action={action}
                reducedMotion={reducedMotion}
                lowCost={lowCost}
                lipSyncByCharacter={lipSyncByCharacter}
                onReady={handleReady}
              />
            </Suspense>
          </PreviewErrorBoundary>
          {!ready && (
            <div className="character-stage-loading" role="status" data-testid="character-stage-loading">
              Setting up your cast…
            </div>
          )}
        </>
      )}
    </div>
  );
}

export default CharacterStage;
