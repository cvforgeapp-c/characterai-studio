export const CHARACTER_ACTIONS = [
  "idle",
  "talk",
  "walk",
  "jump",
  "laugh",
  "cry",
  "angry",
  "surprised",
  "blink",
  "wave",
  "dance",
] as const;

export type CharacterAction = (typeof CHARACTER_ACTIONS)[number];
export type CharacterExpression = "neutral" | "joy" | "sad" | "angry" | "surprised";

/** Normalized mouth input that can be supplied by a future speech/lip-sync provider. */
export interface LipSyncFrame {
  mouthOpen: number;
  viseme?: "sil" | "aa" | "ee" | "ih" | "oh" | "ou" | string;
}

export interface CharacterMotionInput {
  action: CharacterAction;
  reducedMotion?: boolean;
  lipSync?: LipSyncFrame;
}

export interface CharacterPose {
  verticalOffset: number;
  horizontalOffset: number;
  bodyTilt: number;
  headTilt: number;
  headPitch: number;
  armSwing: number;
  legSwing: number;
  mouthOpen: number;
  blink: number;
  eyeSquint: number;
  browTilt: number;
  tears: number;
  expression: CharacterExpression;
}

/** Rig adapters can consume the same pose contract as the procedural meshes. */
export interface CharacterMotionDriver {
  update(deltaSeconds: number, input: CharacterMotionInput): CharacterPose;
}

export function createProceduralMotionDriver(seed = 0): CharacterMotionDriver {
  let time = seed * 0.83;
  const blinkOffset = seed * 1.31;

  return {
    update(deltaSeconds, input) {
      time += Math.min(Math.max(deltaSeconds, 0), 0.05);
      const { action, reducedMotion = false, lipSync } = input;
      const wave = (frequency: number, phase = 0) => Math.sin(time * frequency + phase);
      const blinkCycle = (time + blinkOffset) % 4.7;
      let blink = !reducedMotion && blinkCycle < 0.16
        ? Math.sin((blinkCycle / 0.16) * Math.PI)
        : 0;

      let verticalOffset = 0;
      let horizontalOffset = 0;
      let bodyTilt = 0;
      let headTilt = 0;
      let headPitch = 0;
      let armSwing = 0;
      let legSwing = 0;
      let mouthOpen = 0.055;
      let eyeSquint = 0;
      let browTilt = 0;
      let tears = 0;
      let expression: CharacterExpression = "neutral";

      if (!reducedMotion) {
        verticalOffset = wave(2.2, seed) * 0.035;
        headTilt = wave(1.15, seed * 0.7) * 0.035;
      }

      switch (action) {
        case "talk":
          mouthOpen = reducedMotion ? 0.34 : 0.13 + Math.max(0, wave(10, seed)) * 0.42;
          headTilt += reducedMotion ? 0 : wave(3.2, seed) * 0.035;
          break;
        case "walk":
          expression = "joy";
          if (!reducedMotion) {
            legSwing = wave(8.5, seed) * 0.62;
            armSwing = wave(8.5, seed + Math.PI) * 0.4;
            horizontalOffset = wave(3.2, seed) * 0.12;
            verticalOffset = Math.abs(wave(8.5, seed)) * 0.045;
          }
          mouthOpen = 0.1;
          break;
        case "jump":
          expression = "joy";
          if (!reducedMotion) {
            verticalOffset = Math.max(0, wave(3, seed)) * 0.48;
            armSwing = Math.max(0, wave(3, seed)) * -0.65;
          }
          mouthOpen = reducedMotion ? 0.18 : 0.18 + Math.max(0, wave(3, seed)) * 0.18;
          break;
        case "laugh":
          expression = "joy";
          if (!reducedMotion) {
            verticalOffset = Math.abs(wave(5.8, seed)) * 0.11;
            headTilt = 0.12 + wave(5.8, seed) * 0.09;
            bodyTilt = wave(5.8, seed) * 0.055;
            armSwing = wave(5.8, seed) * 0.45;
          }
          mouthOpen = reducedMotion ? 0.5 : 0.32 + Math.max(0, wave(5.8, seed)) * 0.45;
          eyeSquint = 0.62;
          break;
        case "cry":
          expression = "sad";
          headPitch = reducedMotion ? 0.14 : 0.16 + Math.max(0, wave(2.4, seed)) * 0.08;
          bodyTilt = reducedMotion ? 0 : wave(2.4, seed) * 0.025;
          mouthOpen = reducedMotion ? 0.2 : 0.09 + Math.max(0, wave(2.4, seed)) * 0.2;
          tears = 1;
          break;
        case "angry":
          expression = "angry";
          headPitch = 0.04;
          bodyTilt = reducedMotion ? 0 : wave(13, seed) * 0.025;
          eyeSquint = 0.24;
          browTilt = 0.32;
          mouthOpen = 0.035;
          break;
        case "surprised":
          expression = "surprised";
          mouthOpen = reducedMotion ? 0.72 : 0.58 + Math.max(0, wave(2, seed)) * 0.15;
          break;
        case "blink":
          blink = reducedMotion ? 1 : Math.max(blink, Math.max(0, wave(5.2, seed)) * 0.98);
          break;
        case "wave":
          expression = "joy";
          if (!reducedMotion) {
            armSwing = 0.42 + wave(4.8, seed) * 0.38;
            headTilt = wave(1.8, seed) * 0.04;
            verticalOffset = wave(2.2, seed) * 0.025;
          }
          mouthOpen = 0.1;
          break;
        case "dance":
          expression = "joy";
          if (!reducedMotion) {
            bodyTilt = wave(4.4, seed) * 0.14;
            legSwing = wave(4.4, seed) * 0.72;
            armSwing = wave(4.4, seed + 1) * 0.9;
            verticalOffset = Math.abs(wave(4.4, seed)) * 0.12;
          }
          mouthOpen = 0.18;
          break;
      }

      if (lipSync) {
        mouthOpen = Math.max(mouthOpen, Math.max(0, Math.min(1, lipSync.mouthOpen)));
      }

      return {
        verticalOffset,
        horizontalOffset,
        bodyTilt,
        headTilt,
        headPitch,
        armSwing,
        legSwing,
        mouthOpen,
        blink,
        eyeSquint,
        browTilt,
        tears,
        expression,
      };
    },
  };
}
