export type CharacterId =
  | "lion"
  | "goat"
  | "chicken"
  | "dog"
  | "cat"
  | "monkey"
  | "elephant"
  | "rabbit"
  | "cow"
  | "bear"
  | "tomato"
  | "onion"
  | "potato"
  | "broccoli"
  | "carrot"
  | "banana"
  | "orange";

export type CharacterCategory = "Animals" | "Food";
export type CharacterArchetype =
  | "lion"
  | "goat"
  | "chicken"
  | "dog"
  | "cat"
  | "monkey"
  | "elephant"
  | "rabbit"
  | "cow"
  | "bear"
  | "tomato"
  | "onion"
  | "potato"
  | "broccoli"
  | "carrot"
  | "banana"
  | "orange";

export type CharacterDefinition = {
  id: CharacterId;
  name: string;
  category: CharacterCategory;
  emoji: string;
  description: string;
  tone: string;
  archetype: CharacterArchetype;
  colors: {
    body: string;
    head: string;
    accent: string;
    muzzle: string;
    detail: string;
    foot: string;
  };
  proportions: {
    body: [number, number, number];
    head: [number, number, number];
    size: number;
    legLength: number;
  };
};

const character = (
  id: CharacterId,
  name: string,
  emoji: string,
  description: string,
  tone: string,
  colors: CharacterDefinition["colors"],
  proportions: CharacterDefinition["proportions"],
): CharacterDefinition => ({
  id,
  name,
  emoji,
  description,
  tone,
  category: ["tomato", "onion", "potato", "broccoli", "carrot", "banana", "orange"].includes(id) ? "Food" : "Animals",
  archetype: id,
  colors,
  proportions,
});

export const characters: CharacterDefinition[] = [
  character("lion", "King Leo", "🦁", "A proud village lion with a big personality.", "Confident", { body: "#c9873e", head: "#e9b85d", accent: "#a75125", muzzle: "#f6dfb9", detail: "#47301e", foot: "#8b5129" }, { body: [0.48, 0.62, 0.38], head: [0.52, 0.48, 0.43], size: 1.02, legLength: 0.47 }),
  character("goat", "Gigi Goat", "🐐", "A clever goat who always has a comeback.", "Funny", { body: "#e8dfc9", head: "#f2ead8", accent: "#815a42", muzzle: "#e4ad9b", detail: "#604538", foot: "#65544a" }, { body: [0.42, 0.6, 0.34], head: [0.4, 0.47, 0.36], size: 0.98, legLength: 0.51 }),
  character("chicken", "Chika", "🐔", "A village chicken who knows every secret.", "Gossip", { body: "#f3dfae", head: "#fff0c9", accent: "#c94d37", muzzle: "#e7a94b", detail: "#513324", foot: "#cf7441" }, { body: [0.48, 0.56, 0.4], head: [0.4, 0.39, 0.37], size: 0.88, legLength: 0.36 }),
  character("dog", "Benny Dog", "🐶", "A loyal dog who gets into funny trouble.", "Playful", { body: "#b87845", head: "#d29458", accent: "#70422e", muzzle: "#f0d2a9", detail: "#432a21", foot: "#75462e" }, { body: [0.51, 0.57, 0.36], head: [0.43, 0.4, 0.38], size: 0.96, legLength: 0.43 }),
  character("cat", "Cleo Cat", "🐱", "A curious cat who always lands on her feet.", "Curious", { body: "#e8a85f", head: "#f1bf79", accent: "#d47852", muzzle: "#f8e8d0", detail: "#533729", foot: "#c37e4b" }, { body: [0.42, 0.6, 0.32], head: [0.4, 0.4, 0.34], size: 0.94, legLength: 0.48 }),
  character("monkey", "Milo Monkey", "🐵", "A mischievous monkey with a generous heart.", "Mischievous", { body: "#9a5d3d", head: "#b8734b", accent: "#5c382a", muzzle: "#edc18c", detail: "#38251e", foot: "#63402e" }, { body: [0.48, 0.61, 0.36], head: [0.42, 0.41, 0.38], size: 0.96, legLength: 0.46 }),
  character("elephant", "Ellie Elephant", "🐘", "A gentle giant with a memory for every detail.", "Gentle", { body: "#8b9db2", head: "#aab8c8", accent: "#77879d", muzzle: "#c1a9a8", detail: "#354352", foot: "#707f91" }, { body: [0.61, 0.7, 0.45], head: [0.48, 0.47, 0.44], size: 1.12, legLength: 0.36 }),
  character("rabbit", "Ruby Rabbit", "🐰", "A quick-thinking rabbit with a big imagination.", "Bright", { body: "#f3e7dd", head: "#fff1e7", accent: "#e8b8aa", muzzle: "#f1c7bf", detail: "#503b3b", foot: "#e1b2ac" }, { body: [0.43, 0.58, 0.34], head: [0.41, 0.4, 0.35], size: 1.02, legLength: 0.43 }),
  character("cow", "Coco Cow", "🐮", "A friendly cow who tells the best farmyard stories.", "Friendly", { body: "#f7f1e6", head: "#fff9f0", accent: "#534b4c", muzzle: "#e7a7a0", detail: "#362e31", foot: "#564a47" }, { body: [0.56, 0.64, 0.42], head: [0.48, 0.44, 0.4], size: 1.05, legLength: 0.39 }),
  character("bear", "Bramble Bear", "🐻", "A soft-spoken bear who loves a silly adventure.", "Kind", { body: "#8b5a3e", head: "#a96f4e", accent: "#68422f", muzzle: "#e9c49c", detail: "#3e2b22", foot: "#714b36" }, { body: [0.55, 0.66, 0.42], head: [0.46, 0.43, 0.39], size: 1.04, legLength: 0.4 }),
  character("tomato", "Tina Tomato", "🍅", "A dramatic tomato who cries at everything.", "Dramatic", { body: "#e95c42", head: "#f36a4a", accent: "#448854", muzzle: "#ffcfb0", detail: "#542c24", foot: "#9b4532" }, { body: [0.55, 0.58, 0.45], head: [0.49, 0.45, 0.42], size: 0.96, legLength: 0.34 }),
  character("onion", "Omar Onion", "🧅", "A grumpy onion who thinks he is the boss.", "Angry", { body: "#b595d0", head: "#c9acd9", accent: "#7e5b9d", muzzle: "#edd6d3", detail: "#392b45", foot: "#755d83" }, { body: [0.5, 0.65, 0.39], head: [0.43, 0.45, 0.37], size: 1.02, legLength: 0.38 }),
  character("potato", "Pablo Potato", "🥔", "A kind potato with terrible jokes.", "Friendly", { body: "#bd8d56", head: "#d3a56c", accent: "#825a36", muzzle: "#f0d5ae", detail: "#493323", foot: "#805b3a" }, { body: [0.58, 0.62, 0.43], head: [0.47, 0.42, 0.37], size: 0.93, legLength: 0.34 }),
  character("broccoli", "Brody Broccoli", "🥦", "A fitness-obsessed vegetable.", "Energetic", { body: "#64a858", head: "#77bd5a", accent: "#387848", muzzle: "#d6e5a9", detail: "#28452a", foot: "#577445" }, { body: [0.42, 0.54, 0.37], head: [0.54, 0.51, 0.46], size: 1.06, legLength: 0.39 }),
  character("carrot", "Carla Carrot", "🥕", "A fast-talking carrot who is always on the move.", "Energetic", { body: "#ed8b35", head: "#f2a447", accent: "#4c9b58", muzzle: "#ffe0ad", detail: "#573521", foot: "#96582e" }, { body: [0.39, 0.73, 0.34], head: [0.4, 0.39, 0.35], size: 1.04, legLength: 0.39 }),
  character("banana", "Benny Banana", "🍌", "A cheerful banana who slips into every conversation.", "Cheerful", { body: "#f2ce47", head: "#ffe16a", accent: "#8b6a27", muzzle: "#fff0b1", detail: "#51401f", foot: "#8d682c" }, { body: [0.39, 0.72, 0.33], head: [0.39, 0.4, 0.34], size: 1.06, legLength: 0.4 }),
  character("orange", "Ollie Orange", "🍊", "A sunny orange who can brighten any scene.", "Sunny", { body: "#f28b32", head: "#ffa446", accent: "#4e9950", muzzle: "#ffdfa9", detail: "#55361e", foot: "#92552a" }, { body: [0.53, 0.57, 0.43], head: [0.47, 0.44, 0.4], size: 0.94, legLength: 0.34 }),
];

export const characterById = (id: string): CharacterDefinition | undefined =>
  characters.find((item) => item.id === id);
