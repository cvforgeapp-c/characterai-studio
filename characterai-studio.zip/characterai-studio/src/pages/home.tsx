import { useCallback, useEffect, useMemo, useState } from "react";
import {
  characters,
} from "@/lib/character-catalog";
import {
  CharacterPreviewPanel,
  type PreviewCharacterAction,
  type PreviewCharacterMetadata,
} from "@/components/character-preview";
import { CharacterStage } from "@/components/character-preview/CharacterStage";

function useReducedMotionPreference() {
  const [reducedMotion, setReducedMotion] = useState(
    () => typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches,
  );

  useEffect(() => {
    const media = window.matchMedia("(prefers-reduced-motion: reduce)");
    const updatePreference = (event: MediaQueryListEvent) => setReducedMotion(event.matches);
    media.addEventListener("change", updatePreference);
    return () => media.removeEventListener("change", updatePreference);
  }, []);

  return reducedMotion;
}

const templates = [
  { id: "t1", title: "The Village Argument", tag: "Comedy", emoji: "🏡", characters: "Onion + Tomato", duration: "10 sec", description: "A grumpy onion confronts a tomato in the village." },
  { id: "t2", title: "The Unlikely Date", tag: "Romance", emoji: "🌻", characters: "Broccoli + Potato", duration: "15 sec", description: "Two vegetables go on an awkward first date." },
  { id: "t3", title: "The School Trouble", tag: "Funny", emoji: "🎒", characters: "Dog + Goat", duration: "10 sec", description: "Two classmates try to explain a missing homework." },
];

const workspaceItems = ["Home", "Explore", "Characters", "Templates", "My Videos"];
const workspaceIcons: Record<string, string> = {
  Home: "⌂",
  Explore: "◈",
  Characters: "♙",
  Templates: "▧",
  "My Videos": "▣",
};
const mobileItems = ["Home", "Explore", "Create", "Videos", "Profile"];
const mobileIcons: Record<string, string> = {
  Home: "⌂",
  Explore: "◈",
  Create: "＋",
  Videos: "▣",
  Profile: "♙",
};

export default function Home() {
  const [activeTab, setActiveTab] = useState("Home");
  const [mode, setMode] = useState<"recreate" | "original">("recreate");
  const [category, setCategory] = useState("All");
  const [selected, setSelected] = useState<string[]>(["onion", "tomato"]);
  const [prompt, setPrompt] = useState("");
  const [notice, setNotice] = useState("");
  const [previewAction, setPreviewAction] = useState<PreviewCharacterAction>("idle");
  const [previewError, setPreviewError] = useState("");
  const reducedMotion = useReducedMotionPreference();
  const selectedCharacters = useMemo(
    () => selected.flatMap((id) => {
      const character = characters.find((item) => item.id === id);
      return character ? [character] : [];
    }),
    [selected],
  );
  const selectedKey = selected.join("|");
  const previewCharacter: PreviewCharacterMetadata = selectedCharacters[0] ?? {
    id: "empty-cast",
    name: "Your character preview",
    category: "3D preview",
    tone: "Choose your cast",
    description: "Select one or more characters above to preview them in 3D.",
  };
  const handlePreviewError = useCallback(() => {
    setPreviewError("The 3D preview could not start in this browser. Your cast selection is unchanged.");
  }, []);

  useEffect(() => {
    setPreviewError("");
  }, [selectedKey]);

  const filteredCharacters = useMemo(
    () => characters.filter((character) => category === "All" || character.category === category),
    [category],
  );

  function toggleCharacter(id: string) {
    setSelected((current) =>
      current.includes(id)
        ? current.filter((item) => item !== id)
        : current.length < 4
          ? [...current, id]
          : current,
    );
  }

  function goToCreate() {
    setActiveTab("Create");
    document.getElementById("create-studio")?.scrollIntoView({ behavior: "smooth" });
  }

  function startCreation() {
    if (selected.length === 0) {
      setNotice("Choose at least one character to continue.");
      return;
    }
    if (!prompt.trim()) {
      setNotice("Write a short story or dialogue first.");
      return;
    }
    setNotice("Your creation setup is ready. Video generation will be connected in the next development phase.");
  }

  return (
    <main className="app-shell">
      <aside className="sidebar" aria-label="Workspace navigation">
        <a
          className="brand"
          href="#"
          data-testid="link-brand-home"
          onClick={(event) => {
            event.preventDefault();
            setActiveTab("Home");
            window.scrollTo({ top: 0, behavior: "smooth" });
          }}
        >
          <span className="brand-mark" aria-hidden="true">✦</span>
          <span>Character<span className="brand-accent">AI</span><small>STUDIO</small></span>
        </a>
        <div className="side-label">WORKSPACE</div>
        <nav aria-label="Workspace">
          {workspaceItems.map((item) => (
            <button
              key={item}
              type="button"
              data-testid={`nav-${item.toLowerCase().replaceAll(" ", "-")}`}
              aria-current={activeTab === item ? "page" : undefined}
              className={`nav-item ${activeTab === item ? "active" : ""}`}
              onClick={() => setActiveTab(item)}
            >
              <span className="nav-icon" aria-hidden="true">{workspaceIcons[item]}</span>
              {item}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="credit-card">
            <span className="credit-icon" aria-hidden="true">✧</span>
            <strong>Free plan</strong>
            <p>Starter workspace</p>
            <div className="credit-meter" aria-label="0 video credits used"><span /></div>
            <small>0 video credits used</small>
            <button className="upgrade-btn" type="button" data-testid="button-explore-plans" onClick={() => setNotice("Subscription plans will be added after the MVP.")}>Explore plans ↗</button>
          </div>
          <button className="nav-item profile-item" type="button" data-testid="nav-your-workspace" onClick={() => setActiveTab("Profile")}>
            <span className="avatar" aria-hidden="true">U</span> Your workspace
          </button>
        </div>
      </aside>

      <section className="main-content">
        <header className="topbar">
          <div className="mobile-brand"><span className="brand-mark" aria-hidden="true">✦</span> Character<span className="brand-accent">AI</span></div>
          <div className="breadcrumb">Studio <span>/</span> {activeTab}</div>
          <div className="top-actions"><span className="status-dot" aria-hidden="true" /> All systems ready <button className="avatar small-avatar" type="button" aria-label="Your workspace" data-testid="button-workspace-profile" onClick={() => setActiveTab("Profile")}>U</button></div>
        </header>

        <div className="page-wrap">
          <section className="hero" aria-labelledby="hero-title">
            <div className="hero-copy">
              <div className="eyebrow"><span aria-hidden="true" /> YOUR IMAGINATION, ANIMATED</div>
              <h1 id="hero-title">Give your characters<br /><em>a story to tell.</em></h1>
              <p>Pick your characters, write a scene, and bring your own AI-powered stories to life.</p>
              <button className="primary-btn" type="button" data-testid="button-create-video-hero" onClick={goToCreate}>＋ Create a video <span aria-hidden="true">→</span></button>
            </div>
            <div className="hero-art" role="img" aria-label="Character spotlight: Omar the onion and Tina the tomato">
              <div className="orb orb-one" /><div className="orb orb-two" />
              <div className="hero-character tomato-char" aria-hidden="true">🍅</div>
              <div className="hero-character onion-char" aria-hidden="true">🧅</div>
              <div className="hero-caption"><span className="live-dot" aria-hidden="true" /> CHARACTER SPOTLIGHT <strong>Omar &amp; Tina</strong></div>
            </div>
            <div className="hero-glow" aria-hidden="true" />
          </section>

          <div className="section-heading">
            <div><div className="eyebrow">START CREATING</div><h2>Two ways to make a video</h2></div>
            <span className="section-note">Choose your creative flow</span>
          </div>

          <div className="mode-grid" role="group" aria-label="Choose a creation mode">
            <button className={`mode-card ${mode === "recreate" ? "mode-selected" : ""}`} type="button" aria-pressed={mode === "recreate"} data-testid="button-mode-template" onClick={() => setMode("recreate")}>
              <div className="mode-icon" aria-hidden="true">↻</div><div><span className="mode-kicker">MODE 01</span><h3>Recreate a template</h3><p>Start with a popular idea. Keep its characters and make the story yours.</p><span className="mode-link">Browse templates →</span></div>
              <span className="mode-check" aria-hidden="true">{mode === "recreate" ? "✓" : "＋"}</span>
            </button>
            <button className={`mode-card ${mode === "original" ? "mode-selected" : ""}`} type="button" aria-pressed={mode === "original"} data-testid="button-mode-original" onClick={() => setMode("original")}>
              <div className="mode-icon" aria-hidden="true">✳</div><div><span className="mode-kicker">MODE 02</span><h3>Create your own story</h3><p>Choose characters from scratch and invent a completely new scene.</p><span className="mode-link">Start from scratch →</span></div>
              <span className="mode-check" aria-hidden="true">{mode === "original" ? "✓" : "＋"}</span>
            </button>
          </div>

          <section className="section-block" aria-labelledby="cast-title">
            <div className="section-heading compact">
              <div><div className="eyebrow">BUILD YOUR CAST</div><h2 id="cast-title">Choose your characters</h2><p className="subtext">Select up to 4 characters for your story.</p></div>
              <button className="text-btn" type="button" data-testid="button-view-characters" onClick={() => setActiveTab("Characters")}>View all characters ↗</button>
            </div>
            <div className="filter-row" role="group" aria-label="Filter characters by category">
              {["All", "Animals", "Food"].map((item) => (
                <button key={item} type="button" className={`filter-chip ${category === item ? "filter-active" : ""}`} aria-pressed={category === item} data-testid={`filter-${item.toLowerCase()}`} onClick={() => setCategory(item)}>{item}</button>
              ))}
            </div>
            <div className="character-grid" aria-label="Character gallery">
              {filteredCharacters.map((character) => {
                const isSelected = selected.includes(character.id);
                return (
                  <button key={character.id} type="button" className={`character-card ${isSelected ? "character-selected" : ""}`} aria-pressed={isSelected} aria-label={`${character.name}, ${character.tone} ${character.category}${isSelected ? ", selected" : ""}`} data-testid={`character-${character.id}`} onClick={() => toggleCharacter(character.id)}>
                    <span className="character-select" aria-hidden="true">{isSelected ? "✓" : "+"}</span>
                    <span className={`character-art art-${character.category.toLowerCase()}`} aria-hidden="true">{character.emoji}</span>
                    <span className="character-info"><strong>{character.name}</strong><small>{character.tone} · {character.category}</small></span>
                  </button>
                );
              })}
            </div>
            <div className="selected-strip" aria-live="polite">
              <span>{selected.length} selected</span>
              <div aria-label="Selected characters">
                {selected.map((id) => {
                  const character = characters.find((item) => item.id === id);
                  return character ? <span className="selected-avatar" key={id} title={character.name} aria-label={character.name}>{character.emoji}</span> : null;
                })}
              </div>
              <button type="button" data-testid="button-clear-selection" onClick={() => setSelected([])}>Clear selection</button>
            </div>
          </section>

          <section className="section-block character-preview-section" aria-labelledby="character-preview-heading">
            <div className="section-heading compact">
              <div>
                <div className="eyebrow">MEET YOUR CAST</div>
                <h2 id="character-preview-heading">3D character preview</h2>
                <p className="subtext">Drag to look around, then try an expression or action.</p>
              </div>
              <span className="preview-engine-pill" aria-label="Runs in your browser">LOCAL PREVIEW</span>
            </div>
            <CharacterPreviewPanel
              character={previewCharacter}
              characters={selectedCharacters}
              activeAction={previewAction}
              onAction={setPreviewAction}
              error={previewError || undefined}
              fallbackContent={
                <>
                  <strong>Select your cast</strong>
                  <span className="character-preview__state-detail">The 3D stage is ready when you are.</span>
                </>
              }
              scene={
                selectedCharacters.length > 0
                  ? (
                    <CharacterStage
                      key={selectedKey}
                      characters={selectedCharacters}
                      action={previewAction}
                      reducedMotion={reducedMotion}
                      onError={handlePreviewError}
                    />
                  )
                  : null
              }
            />
          </section>

          <section className="section-block create-panel" id="create-studio" aria-labelledby="create-title">
            <div className="section-heading compact">
              <div><div className="eyebrow">YOUR NEXT SCENE</div><h2 id="create-title">{mode === "recreate" ? "Make this template yours" : "Describe your story"}</h2><p className="subtext">{mode === "recreate" ? "Choose a starting idea, then customize the prompt." : "Tell us what happens. Your characters are ready."}</p></div>
              <span className="step-pill">STEP 1 OF 3</span>
            </div>
            {mode === "recreate" && (
              <div className="template-row" aria-label="Story templates">
                {templates.map((template) => (
                  <button className="template-card" type="button" key={template.id} data-testid={`template-${template.id}`} aria-label={`Use template: ${template.title}`} onClick={() => setPrompt(template.description)}>
                    <span className="template-emoji" aria-hidden="true">{template.emoji}</span>
                    <span className="template-tag">{template.tag} · {template.duration}</span>
                    <strong>{template.title}</strong>
                    <small>{template.characters}</small>
                  </button>
                ))}
              </div>
            )}
            <label className="field-label" htmlFor="story-prompt">STORY OR DIALOGUE</label>
            <textarea id="story-prompt" data-testid="input-story-prompt" value={prompt} onChange={(event) => setPrompt(event.target.value)} placeholder="Example: The angry onion catches the tomato stealing vegetables from his garden. The tomato starts crying and makes funny excuses..." />
            <div className="form-bottom"><span>{selected.length} characters selected</span><button className="primary-btn" type="button" data-testid="button-continue-settings" onClick={startCreation}>Continue to settings <span aria-hidden="true">→</span></button></div>
            {notice && <div className="notice" role="status" aria-live="polite" data-testid="status-notice">{notice}</div>}
            <p className="prototype-note">Preview build · Video generation, accounts, and payments will be connected in upcoming phases.</p>
          </section>

          <footer>© 2026 CharacterAI Studio <span>Made for stories worth sharing.</span></footer>
        </div>
      </section>
      <nav className="mobile-nav" aria-label="Mobile navigation">
        {mobileItems.map((item) => (
          <button key={item} type="button" data-testid={`mobile-nav-${item.toLowerCase()}`} aria-current={activeTab === item || (item === "Videos" && activeTab === "My Videos") ? "page" : undefined} className={activeTab === item || (item === "Videos" && activeTab === "My Videos") ? "mobile-active" : ""} onClick={() => { if (item === "Create") goToCreate(); else setActiveTab(item === "Videos" ? "My Videos" : item); }}>
            <span aria-hidden="true">{mobileIcons[item]}</span>{item}
          </button>
        ))}
      </nav>
    </main>
  );
}
